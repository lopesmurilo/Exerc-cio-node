const fs = require('fs').promises; // Sistema de arquivos (jeito moderno que não trava o sistema)
const path = require('path'); // Manipulação de caminhos

class Logger {
  constructor(logFile = 'app.log') {
    const __dirname = path.resolve();
    this.logfile = path.join(__dirname, logFile);
    console.log(`Logger criado! Arquivo: ${this.logfile}`);
  }

  async log(message, level = 'INFO') {
    const timestamp = new Date().toISOString(); // Pega a data/hora atual e transforma em string
    const logEntry = `[${timestamp}] ${level}: ${message}\n`;

    try {
      await fs.appendFile(this.logfile, logEntry);
      console.log(`✅ Log salvo: ${level} - ${message}`);
    } catch (error) {
      console.error(`❌ Erro ao escrever log:`, error.message);
    }
  }

  async info(message) {
    await this.log(message, 'INFO');
  }

  async error(message) {
    await this.log(message, 'ERROR');
  }

  async warn(message) {
    await this.log(message, 'WARN');
  }
}

module.exports = Logger;
