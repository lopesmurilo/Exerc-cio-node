const fs = require('fs').promises;

async function escreverMeuArquivo() {
  try {
    console.log('🔥 Criando um novo arquivo...');

    const meuTexto = 'Arquivo criado pelo Node.js! \nData: ' + new Date().toLocaleString() + '\nEste arquivo foi gerado automaticamente.';

    await fs.writeFile('arquivo-criado.txt', meuTexto, 'utf8');

    console.log('✅ Arquivo "arquivo-criado.txt" criado com sucesso!');
    console.log('📜 Conteúdo escrito:');
    console.log('-'.repeat(40));
    console.log(meuTexto);
    console.log('-'.repeat(40));

  } catch (error) {
    console.error('❌ Erro ao escrever arquivo:', error.message);
  }
}

escreverMeuArquivo();
