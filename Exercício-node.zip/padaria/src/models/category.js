class Category {
  constructor(id, name, description, icon) {
    this.id = id; // Número da seção (1, 2, 3...)
    this.name = name; // Nome da seção ("Pães", "Bolos"...)
    this.description = description; // O que tem nesta seção
    this.icon = icon; // Emoji da seção (🍞, 🍰...)

    this.active = true; // Seção está funcionando?
    this.createdAt = new Date(); // Quando foi criada
    this.productCount = 0; // Quantos produtos tem aqui
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      icon: this.icon,
      active: this.active,
      createdAt: this.createdAt,
      productCount: this.productCount,
    };
  }

  update(newData) {
    if (newData.name) this.name = newData.name; // Novo nome?
    if (newData.description) this.description = newData.description; // Nova descrição
    if (newData.icon) this.icon = newData.icon; // Novo emoji?
    if (newData.active !== undefined) this.active = newData.active; // Ativar/desativar
  }

  addProduct() {
    this.productCount++; // Conta +1 produto
  }

  removeProduct() {
    if (this.productCount > 0) {
      this.productCount--; // Conta -1 produto (se tiver algum)
    }
  }
}

module.exports = Category;


const secaoPaes = new Category(
  1, 
  'Pães', 
  'Pães frescos e quentinhos', 
  '🍞'
);

secaoPaes.addProduct(); // Colocamos 1 pão
console.log('Quantos produtos temos?', secaoPaes.productCount); // 1

// Pronto! Nossa seção de pães está funcionando!

